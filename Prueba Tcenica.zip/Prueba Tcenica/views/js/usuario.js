$(document).ready(function () {
  $("#loginForm").submit(function (e) {
    e.preventDefault();

    // Obtener los datos del formulario
    var perfil = $("#perfil").val();
    var usuario = $("#usuario").val();
    var password = $("#password").val();

    // solicitud AJAX
    $.ajax({
      url: "ajax/ajax.usuarios.php",
      method: "POST",
      dataType: "json",
      data: {
        ingUsuario: usuario,
        ingPassword: password,
        ingPerfil: perfil,
      },
      success: function (response) {
        console.log(response);
        if (response.success) {
          window.location.href = "views/modulos/inicio.php";
        } else {
          $("#response").html(
            '<div class="alert alert-danger">' + response.message + "</div>"
          );
        }
      },
      error: function (jqXHR, textStatus, errorThrown) {
        console.error("Error en la solicitud AJAX: ", textStatus, errorThrown);
        console.log("Respuesta del servidor:", jqXHR.responseText);
      },
    });
  });
});
