<?php
    session_start();
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <link rel="icon" href="ruta/a/tu/favicon.ico" type="image/x-icon">
    <!-- jQuery para manejar el AJAX -->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>;

    <!-- estilos personalizados -->
    <link rel="stylesheet" href="views/css/estilos.css">
</head>
<body>
    <?php 
        if (isset($_SESSION["iniciarSesion"]) && $_SESSION["iniciarSesion"] == "ok") {
            include "modulos/incio.php";
        } else  {   
            include "modulos/login.php";
        }
    ?>
    
    <!-- Ruta corregida para el archivo usuario.js -->
    <script src="views/js/usuario.js"></script>
</body>
</html>
