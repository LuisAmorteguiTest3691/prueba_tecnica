<?php
session_start();

require_once "../../models/usuarios.modelo.php"; 
require_once "../../controllers/autenticas.controlador.php"; 

if (!isset($_SESSION["iniciarSesion"])) {
    header("Location: ../index.php");
    exit();
}

$usuarios = ControladorLoginUsuarios::llamarTodosUsuarios(null, null);

echo "<h1>Bienvenido " . $_SESSION["usuario"] . "</h1>";
?>

<!-- Botón de logout -->
<form method="post">
    <button type="submit" name="logout">Cerrar sesión</button>
</form>

<?php

if (isset($_POST['logout'])) {
    session_destroy();
    header("Location: ../../index.php");
    exit();
}
?>

<!-- Mostrar la tabla de usuarios -->
<table border="1">
    <thead>
        <tr>
            <th>ID Usuario</th>
            <th>Perfil</th>
            <th>Trabajador</th>
            <th>Usuario Login</th>
        </tr>
    </thead>
    <tbody>
        <?php foreach ($usuarios as $usuario): ?>
            <tr>
                <td><?php echo $usuario['id_usuario']; ?></td>
                <td><?php echo $usuario['perfil']; ?></td>
                <td><?php echo $usuario['trabajador']; ?></td>
                <td><?php echo $usuario['usuario_login']; ?></td>
            </tr>
        <?php endforeach; ?>
    </tbody>
</table>
