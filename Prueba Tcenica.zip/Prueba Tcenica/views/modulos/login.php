<form id="loginForm">
    <h2>Login</h2>

    <!-- Select para el perfil -->
    <select id="perfil" required>
        <option value="">Seleccione un perfil</option>
        <?php
            $perfiles = ControladorLoginUsuarios::mostrarPerfilesUnicos(); 

            foreach ($perfiles as $key => $value) {
                echo '<option value="'.$value["id_perfil"].'">'.$value["perfil"].'</option>';
            }
        ?>
    </select>

    <!-- Select para el usuario -->
    <select id="usuario" required>
        <option value="">Seleccione un usuario</option>
        <?php
            $usuarios = ControladorLoginUsuarios::llamarTodosUsuarios("usuario", "usuario_login");
            foreach ($usuarios as $key => $value) {
                echo '<option value="'.$value["usuario_login"].'">'.$value["usuario_login"].'</option>';
            }
        ?>
    </select>

    <input type="password" id="password" placeholder="Contraseña" name="ingPassword" required>
    <button type="submit">Iniciar sesión</button>

    <div id="response"></div>
</form>
