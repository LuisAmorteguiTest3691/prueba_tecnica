<?php

class ControladorLoginUsuarios {
    // llamar todos los usarios
    static public function llamarTodosUsuarios($tabla, $item) {
        $respuesta = ModeloUsuarios::MdlMostrarUsuarios($tabla, $item, null);

        return $respuesta;
    }

    // mostrar solo perfiles en las listas
    static public function mostrarPerfilesUnicos() {
        $tabla = "perfil";
        $respuesta = ModeloUsuarios::mdlMostrarPerfilesUnicos($tabla);
        return $respuesta;
    }

    // Método para obtener todos los usuarios
    static public function ctrMostrarUsuarios() {
        $tabla = "usuario";
        $respuesta = ModeloUsuarios::mdlMostrarTodosUsuarios($tabla);
        return $respuesta;
    }
    
    public static function ctrIngresoUsuario($usuario, $password, $perfilSeleccionado) {
        if (preg_match('/^[a-zA-Z0-9]+$/', $usuario) && preg_match('/^[a-zA-Z0-9]+$/', $password)) {
            
            $respuesta = ModeloUsuarios::MdlMostrarUsuarios("usuario", "usuario_login", $usuario);
    
            // Verificar si el usuario fue encontrado
            if ($respuesta) {
                // Verificar si el id_perfil seleccionado coincide con el id_perfil del usuario en la base de datos
                if ($respuesta["id_perfil"] == $perfilSeleccionado) {
                    // Verificar si la contraseña es correcta
                    if ($respuesta["usuario_clave"] == $password) {
                        session_start();
                        $_SESSION["iniciarSesion"] = "ok";
                        $_SESSION["usuario"] = $respuesta["usuario_login"];
                        $_SESSION["perfil"] = $respuesta["perfil"];
                        
                        return ['success' => true, 'message' => 'Login exitoso'];
                    } else {
                        return ['success' => false, 'message' => 'Contraseña incorrecta'];
                    }
                } else {
                    return ['success' => false, 'message' => 'Perfil incorrecto'];
                }
            } else {
                return ['success' => false, 'message' => 'Usuario no encontrado'];
            }
        } else {
            return ['success' => false, 'message' => 'Formato de datos no válido'];
        }
    }
}