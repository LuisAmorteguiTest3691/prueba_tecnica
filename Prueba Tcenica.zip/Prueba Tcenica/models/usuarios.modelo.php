<?php

require_once "conexion.php";

class ModeloUsuarios {
    // Mostrasr Usuarios para login
    static public function MdlMostrarUsuarios($tabla, $item, $valor) {
        if ($valor != null) {
            $stmt = Conexion::conectar()->prepare("
                SELECT usuario.*, perfil.perfil 
                FROM usuario 
                INNER JOIN perfil ON usuario.id_perfil = perfil.id_perfil 
                WHERE $item = :$item
            ");
            $stmt->bindParam(":".$item, $valor, PDO::PARAM_STR);
            $stmt->execute();

            return $stmt->fetch(PDO::FETCH_ASSOC);
        } else {
            $stmt = Conexion::conectar()->prepare("
                SELECT usuario.*, perfil.perfil 
                FROM usuario 
                INNER JOIN perfil ON usuario.id_perfil = perfil.id_perfil
            ");
            $stmt->execute();
    
            return $stmt->fetchAll(PDO::FETCH_ASSOC);
        }
    }

    // mostrar todos los usuarios
    static public function mdlMostrarTodosUsuarios($tabla) {
        $stmt = Conexion::conectar()->prepare("
            SELECT usuario.*, perfil.perfil 
            FROM usuario 
            INNER JOIN perfil ON usuario.id_perfil = perfil.id_perfil
        ");
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    // metodo para obtener toda la tabla perfil
    static public function mostrarSoloPerfilesListas($tabla) {
        $stmt = Conexion::conectar()->prepare("SELECT perfil FROM $tabla");

        $stmt->execute();
        
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    // Método para obtener todos los perfiles únicos
    static public function mdlMostrarPerfilesUnicos($tabla) {
        $stmt = Conexion::conectar()->prepare("SELECT DISTINCT id_perfil, perfil FROM $tabla");
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
}
