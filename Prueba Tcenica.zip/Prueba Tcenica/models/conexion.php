<?php
class Conexion {
    static public function conectar() {
        try {
            $link = new PDO("mysql:host=localhost;dbname=pruebastecnicas", "root", "", [
                PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC, 
                PDO::ATTR_PERSISTENT => true,
            ]);
            $link->exec("set names utf8");
            return $link;
        } catch (PDOException $e) {
            die("Error en la conexión: " . $e->getMessage());
        }
    }
}