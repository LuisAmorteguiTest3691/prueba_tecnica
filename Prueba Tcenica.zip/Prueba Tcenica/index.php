<?php

// depurador de errores
ini_set("display_errors", 1);
ini_set("log_errors", 1);
ini_set("error_log", "C:\Prueba Tcenica/php_error_log");
error_reporting(E_ALL);

// controladores
require_once "controllers/plantilla.php";
require_once "controllers/autenticas.controlador.php";

// modelos
require_once "models/usuarios.modelo.php";


$vistaLogin = new ControladorPlantilla();
$vistaLogin->ctrPlantilla();

