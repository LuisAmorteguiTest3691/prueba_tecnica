<?php

require_once "../controllers/autenticas.controlador.php";
require_once "../models/usuarios.modelo.php";

class AjaxUsuarios {

    public $ingUsuario;
    public $ingPassword;
    public $ingPerfil;

    public function ajaxLoginUsuario() {
        $respuesta = ControladorLoginUsuarios::ctrIngresoUsuario($this->ingUsuario, $this->ingPassword, $this->ingPerfil);
        
        echo json_encode($respuesta);
    }
}

if (isset($_POST["ingUsuario"]) && isset($_POST["ingPassword"]) && isset($_POST["ingPerfil"])) {
    $login = new AjaxUsuarios();
    $login->ingUsuario = $_POST["ingUsuario"];
    $login->ingPassword = $_POST["ingPassword"];
    $login->ingPerfil = $_POST["ingPerfil"];
    $login->ajaxLoginUsuario();
}
